<?php
//COISAS PRA ARRUMAR:
//LOCAL DO REQUIRE

require '../Models/Usuario.php';
require '../Models/UsuarioCrud.php';


//TESTE DO INSERT USUARIO(PEGA INFORMAÇÕES DO FORMULARIO POR MEIO DE POST, E INSERE NO BANCO)
//DADOS CHEGANDO DO FORMULARIO
//if ($_GET['acao'] = 'cadastrar') {
//    $user = new Usuario($_POST['nome'], $_POST['senha'], $_POST['email'], $_POST['telefone'], $_POST['cpf'], $_POST['endereco']);
//    $test = new UsuarioCrud();
//    $resultado = $test->insertUsuario($user);
//
//    header("Location: ../Views/Formularios/login.php");
//}


if ($_GET['acao'] = 'login' and isset($_POST['nome']) and isset($_POST['senha'])){
    $user = new Usuario($_POST['nome'],$_POST['senha']);
    $crud = new UsuarioCrud();
    $crud->LoginUsuario($user);

}else{
    header("Location: ../Views/Formularios/login.php?erro=1");

}



//TESTE UpdateUsuario BASEADO NO TRABALHO LOJA ANO PASSADO, AINDA NAO FUNCIONANDO
//    $crud = new UsuarioCrud();
//    $produto = new Usuario($_POST["nome"], $_POST["senha"], $_POST["email"], $_POST["telefone"], $_POST['cpf'], $_POST['endereco']);
//    $crud->updateUsuario($crud);
//    header("location: ../Views/PaginaPrincipal/index.phtml");

//TESTE DO INSERT USUARIO(PEGA INFORMAÇÕES DO FORMULARIO POR MEIO DE POST, E INSERE NO BANCO)
//DADOS CHEGANDO DO FORMULARIO
//    $user = new Usuario($_POST['nome'], $_POST['senha'], $_POST['email'], $_POST['telefone'], $_POST['cpf'], $_POST['endereco']);
//
//    $test = new UsuarioCrud();
//    $resultado = $test->insertUsuario($user);
//    header("Location: ../Views/Formularios/login.php");

//TESTE DO getUsuarios(PEGA DO BANCO TODOS OS USUARIOS)nao esta pegado o id
//      $test = new UsuarioCrud();
//      $resultado = $test->getUsuarios();
//      print_r($resultado);

//TESTE DO getUsuario(PEGA DO BANCO DE ACORDO COM ID)
//    $test = new UsuarioCrud();
//    $resultado = $test->getUsuario(2);
//    print_r($resultado);
