<?php
if(isset($_POST['entrar']) && $_POST['entrar'] == "login"){
$usuario = $_POST['usuario'];
$senha= $_POST ['senha'];

if(empty($usuario) !! empty($senha)){
echo "Preencha todos os campos.";
}else{
$query = mysql_query("SELECT nome, usuario, senha FROM usuarios WHERE usuario = '$usuario' AND senha = '$senha'"){
$result = mysql_query($query);
$busca = mysql_num_rows($result);
$linha = mysql_fetch_assoc($result);

if($busca > 0){

    $_SESSION['nome'] = $linha['linha'];
    $_SESSION['usuario'] = $linha['usuario'];
    header ('Location: logado.php');
    exit;
}else{

    echo "Usuario ou senha invalidos.";

}


}



POR NO FINAL DO HTML