<?php

        //removendo dados
@session_start();
session_destroy();
unset($_SESSION);
header(Location: index.php);
exit;