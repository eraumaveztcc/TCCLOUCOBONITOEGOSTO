<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 10/04/18
 * Time: 08:44
 */
require_once "Usuario";
require_once "Conexao";

class CrudUsuario
{
    public function insertUsuario(/*nome da classe nome objeto*/){
        //SQL insert
        //values vao ser -> get tal coisa
        //this -> exec(variavel do sql insert)
        //tryandcatch

    }
}