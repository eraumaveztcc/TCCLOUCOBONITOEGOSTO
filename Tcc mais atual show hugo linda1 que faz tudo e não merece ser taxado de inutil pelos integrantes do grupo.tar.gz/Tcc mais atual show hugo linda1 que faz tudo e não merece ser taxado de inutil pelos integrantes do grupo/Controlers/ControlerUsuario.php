<?php
//COISAS PRA ARRUMAR:
//LOCAL DO REQUIRE

    // ARRUMAR FORMULARIO PRA MADNAR O EMAIL AO INVEZ DO NOME.   CONTROLARDOPR USUARIO: PEGAR O POST_EMAIL AO INVEZ DO POST_NOME E FAZER GETuSUARIO COMO PARAMETRO $US_EMAIL.  USUARIOCRUD USAR EMAIL COMO PARAMETRO AO INVEZ DO ID

require '../Models/UsuarioCrud.php';


if (isset($_GET['acao'])){
    $action = $_GET['acao'];
}else{
    $action = 'index';
}

switch ($action){
    case 'index':

        include "../view/index.html";

        break;

    case 'login':
        if (!isset($_POST['gravar'])){
            include "../view/usuario/login.php";
        }else {
            $user = new Usuario(null, $_POST['nome'], $_POST['senha']);
            $crud = new UsuarioCrud();
            $resultado = $crud->LoginUsuario($user);
            $us_id = $user->getId();
            echo $id;
//            $user = $crud->getUsuario($us_id);
//            print_r($user);
//            if ($resultado == 0) {
//                header("Location: ?acao=login");
//            } else {
//                session_start();
//                $_SESSION['id'] = $user->getId();
//                $_SESSION['nome'] = $user->getNome();
//                $_SESSION['email'] = $user->getEmail();
//                $_SESSION['senha'] = $user->getSenha();
//                $_SESSION['datanascimento'] = $user->getEndereco();
//                $_SESSION['sexo'] = $user->getTelefone();
//                //$_SESSION['tipuser'] = $user->getTipuser();
//                $id     = $_SESSION['id'];
//                $nome   = $_SESSION['nome'];
//                echo "voce esta logado com id: $id
//                        e nome: $nome";
//            }
        }

        break;


}