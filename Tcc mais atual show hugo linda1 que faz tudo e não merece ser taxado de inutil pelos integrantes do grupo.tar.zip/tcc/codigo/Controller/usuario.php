<?php

require_once "../CrudUsuario.php";
require_once "../Usuario.php";

$action = $_POST['acao'];

switch ($action){
    case 'cadastrar':
        $user = new Usuario($_POST['nome'],$_POST['senha'],$_POST['senha'],$_POST['datanascimento'],$_POST['sexo']);
        $crud = new CrudUsuario();
        $resultado = $crud->insertUsuario($user);

        break;


}
